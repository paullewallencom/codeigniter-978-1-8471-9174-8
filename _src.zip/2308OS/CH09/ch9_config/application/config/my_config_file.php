<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['first_config_item'] = "This is my config setting, there are many like it but this one is mine<br />";

$config['stop_at'] = 10;