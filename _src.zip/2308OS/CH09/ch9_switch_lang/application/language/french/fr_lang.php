<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
$lang['form_title'] = "Titre du formulaire en anglais"; 
$lang['form_email'] = "Votre E-Mail: "; 
$lang['form_submit_button'] = "Suggérer"; 
