<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
$lang['form_title'] = "Form title in English"; 
$lang['form_email'] = "Email: "; 
$lang['form_submit_button'] = "Submit"; 
