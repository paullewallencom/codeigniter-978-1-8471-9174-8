
<?php
echo '<p>This page is being viewed with HTTPS.</p>';

echo anchor ('without_https','Click here to view a page without HTTPS') ;
?>
